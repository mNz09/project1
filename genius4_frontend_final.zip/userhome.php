<?php  ?>

<!DOCTYPE html>
<html>
<head>
	<title>User Dashboard</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta http-equiv="Cache-control" content="no-cache">
</head>

<body>
	<div class="header">
		<img src="images/logo.png" alt="logo here">
		<!-- <img src="logo.png" alt="logohere"> -->

	<nav id="navbar">
			<ul>
				<li><a class="navmenu" id="current" href="userhome.php" >Home</a></li>
				<li><a class="navmenu" href="myprof.php" >My Profile</a></li>
				<li><a class="navmenu" href="myprojs.php" >My Projects</a></li>
				<li><a class="navmenu" href="index.php" >Logout</a></li>
			</ul>
		
	</nav>
	</div>
	<h2>Employee Leaderboard</h3>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
	tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
	cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
	
	<br><br>
	<hr>
	<br><br>
	<h2>Due Projects</h3>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
	tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
	cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

	<footer class="footer">
			<br>
			<a class="footerlink " href="about.php">About Us</a> 
			<a class="footerlink " href="contact.php">Contact </a> <br>
			
			<p>
			Copyright &copy; 2020, Arif Systems. Created by TeamGenius</p>
			<br>
			
	</footer>

</body>
</html>