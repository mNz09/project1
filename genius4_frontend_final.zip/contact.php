<?php  ?>

<!DOCTYPE html>
<html>
	<head>
		<title>Contact | Arif Systems</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/blog.css">
		
	</head>
	<body>
		<div class="header">
			<img src="images/logo.png" alt="logo here">
			<!-- <img src="logo.png" alt="logohere"> -->
		</div>
		<div class="area">
			<h2>Contact US</h2>
			<p> We provide services to research institutes and education providers. For services of Research Management, Data Management & Analysis, Software Development, Project & Product Management, Survey Management, Training and Event Management, please feel free to contact us via email at:<br> info@arifsystems.org
			</p>
			<p>Find by Google Map:

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3312.692090306446!2d151.20390001473388!3d-33.87182538065541!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12ae38da8a3bdf%3A0x2d1c706b75edda18!2sMIT%20Sydney!5e0!3m2!1sen!2sau!4v1602600789092!5m2!1sen!2sau" width="720" height="250" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

			</p>
		</div>

		<footer class="footer">
			<br>
			<a class="footerlink " href="about.php">About Us</a> 
			<a class="footerlink " href="contact.php">Contact </a> <br>
			
			<p>
			Copyright &copy; 2020, Arif Systems. Created by TeamGenius</p>
			<br>
			
		</footer>

	</body>
</html>