<?php
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome | Arif Systems</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta http-equiv="Cache-control" content="no-cache">
	
</head>
<body>
	<div class="header">
		<img src="images/logo.png" alt="logo here">
			<!-- <img src="logo.png" alt="logohere"> -->
	</div>
	<div class="bigarea">
		<p>Welcome to Arif Systems, please choose your portal.</p> <br> <br> <hr><br>
		<div class="smallarea">
			<a class="button" href="adlogin.php">Admin   </a>
		</div>
			<br><hr><br>
		<div class="smallarea">
			<a class="button" href="emplogin.php">Employee</a>
		</div>
		<br><hr>
	</div>

	<div class="footer-top">
		
	</div>
		
	<footer class="footer">
			<br>
			<a class="footerlink " href="about.php">About Us</a> 
			<a class="footerlink " href="contact.php">Contact </a> <br>
			
			<p>
			Copyright &copy; 2020, Arif Systems. Created by TeamGenius</p>
			<br>
			
	</footer>

</body>
</html>