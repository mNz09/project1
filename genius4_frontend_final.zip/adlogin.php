<?php
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Login | Arif Systems</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta http-equiv="Cache-control" content="no-cache">
</head>
<body>
	<div class="header">
		<img src="images/logo.png" alt="logo here">
			<!-- <img src="logo.png" alt="logohere"> -->
	</div>

	<div class="form-area">
		<form action="connect.php" method="post">
			<h3>Admin Login</h3>
			<br>
			<label>Email:</label>
			<br>
			<input type="email" name="mail" placeholder="enter email" required="required">
			<br>
			<label>Password:</label>
			<br>
			<input type="password" name="pass" placeholder="enter password" required="required" >
			<br>
			<br>
			<br>
			<!-- <input class="button" type="button" name="submit" value="Login"> -->
			<!-- Remove line below and discomment line above. -->
			<a href="adminhome.php" class="button">Login</a> 
			<br>
			<br>
			<!-- <a class="button" href="register.php">Register</a> -->

		</form>
	</div>
	<footer class="footer">
			<br>
			<a class="footerlink " href="about.php">About Us</a> 
			<a class="footerlink " href="contact.php">Contact </a> <br>
			
			<p>
			Copyright &copy; 2020, Arif Systems. Created by TeamGenius</p>
			<br>
			
	</footer>

</body>
</html>