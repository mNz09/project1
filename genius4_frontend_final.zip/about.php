<?php  ?>
<!DOCTYPE html>
<html>
<head>
	<title>About Us | Arif Systems</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/blog.css">
</head>
<body>
	<div class="header">
		<img src="images/logo.png" alt="logo here">
		<!-- <img src="logo.png" alt="logohere"> -->
	</div>
	<div class="area">
		<h2>About Us</h2>
		<p>We are based in Melbourne, Australia. We provide expertise, advisory and implementation services in digital systems and data analytics and help your research and idea grow faster and smarter. Our team of experts supports a broad range of management, research and system development activities by bringing all the necessary knowledge sources together in one place through regular consultations and workshops. You tell us about your ideas and plans and we make that happen, even if that sounds a bit crazy!</p>

		<img src="images/about1.jpg" alt="imagehere">
	</div>
	<footer class="footer">
		<br>
		<a class="footerlink " href="about.php">About Us</a> 
		<a class="footerlink " href="contact.php">Contact </a> <br>
		
		<p>
		Copyright &copy; 2020, Arif Systems. Created by TeamGenius</p>
		<br>
		
	</footer>
</body>
</html>